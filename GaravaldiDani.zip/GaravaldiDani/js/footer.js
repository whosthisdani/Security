(function () {
    'use strict';
    const app = angular.module('app');

    app.component('footerCtrl', {
        // Load the template
        templateUrl: '/GaravaldiDani/html/footer.html'
    });
})();