(function () {
    'use strict';
    var app = angular.module('app');

    app.component('portfolio', {
        // Load the template
        templateUrl: './html/portfolio.html',
    });

})();
